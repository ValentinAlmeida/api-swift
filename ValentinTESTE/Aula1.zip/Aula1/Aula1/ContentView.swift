//
//  ContentView.swift
//  Aula1
//
//  Created by Student14_02 on 16/11/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        GeometryReader { geometry in
            VStack {
                // Imagem retangular original
                Image("caminhao")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .alignmentGuide(.top) { _ in
                        0
                    }

                // ZStack para posicionar o texto sobre a imagem circular
                ZStack {
                    // Imagem estilizada como uma bola/círculo
                    Image("caminhao")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .clipShape(Circle())
                        .frame(width: 400, height: 400)

                    // Texto "Hackatruck" centralizado acima da imagem circular
                    Text("Hackatruck")
                        .font(.system(size: 35))
                        .offset(y: -70) // Ajuste a posição vertical do texto conforme necessário
                        .fontWeight(.bold)
                        .foregroundColor(.blue)
                }
            }
        }
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
