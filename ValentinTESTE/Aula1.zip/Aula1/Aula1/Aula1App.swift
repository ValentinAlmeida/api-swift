//
//  Aula1App.swift
//  Aula1
//
//  Created by Student14_02 on 16/11/23.
//

import SwiftUI

@main
struct Aula1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
