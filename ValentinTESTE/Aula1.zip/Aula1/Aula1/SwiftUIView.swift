//
//  SwiftUIView.swift
//  Aula1
//
//  Created by Student14_02 on 16/11/23.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        VStack {
            Image("caminhao")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 360, height: 400)

            Text("HackaTruck")
                .bold()
                .foregroundColor(.blue)
                .font(.system(size: 35))
                .fontWeight(.bold)
                .padding(.top, -60)
            HStack {
                        Text("Maker")
                            .foregroundColor(.yellow)
                        
                        Text("Space")
                            .foregroundColor(.red)
                    }
                    .font(.title)
                    .padding(.top, -40)
        }
        
        
    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        SwiftUIView()
    }
}
